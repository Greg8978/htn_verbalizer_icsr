#include <iostream>

#include <msgClient.hh>
#include <hatpPlan.hh>

int main(int argc, char ** argv){
	if(argc!=2){
		std::cout<<"Usage : "<<argv[0]<<" name"<<std::endl;
		std::cout<<"\tname : Name of the client."<<std::endl;
		exit(50);
	}
	
	std::string name=argv[1]; //Name should actually be the same as Michelangelo supervisor !!!
	
	std::string answer;
	
	//--------- BEGIN MINIMUM CODE : BLOCKING MODE ---------//
	msgClient client;
	client.connect(name, "localhost", 5500);
	
	while(client.isConnected()){
		std::pair<std::string, std::string> result = client.getBlockingMessage();
		std::cout<<"#### Answer : \n"<<result.second<<std::endl;
		answer=result.second;
	}
	//--------- END MINIMUM CODE ---------//
	
	//--------- BEGIN MINIMUM CODE : NON-BLOCKING MODE ---------//
//	msgClient client;
//	client.connect(name, "localhost", 5500);
//	
//	while(client.isConnected()){
//		if(client.isMessageWaiting()){
//			std::pair<std::string, std::string> result = client.getMessage();
//			std::cout<<"#### Answer : \n"<<result.second<<std::endl;
//			answer=result.second;
//		}else{
//			usleep(1000);
//		}
//	}
	//--------- END MINIMUM CODE ---------//
	
	//--------- BEGIN MINIMUM CODE : NON-BLOCKING MODE (TIMEOUTED) ---------//
//	msgClient client;
//	client.connect(name, "localhost", 5500);
//	
//	while(client.isConnected()){
//		unsigned long timeInMs=1000;
//		std::pair<std::string, std::string> result = client.getMessageTimeout(1000);
//		if(result.second!=STATUS_TIMEOUT){
//			std::cout<<"#### Answer : \n"<<result.second<<std::endl;
//			answer=result.second;
//		}
//	}
	//--------- END MINIMUM CODE ---------//
	
	
	
	
	
	
	//--------- BEGIN MINIMUM CODE LIBHATP ---------//
	removeFormatting(answer);
	if(testInputValidity(answer)){
		hatpPlan plan(answer);
		
		std::cout<<"----- Plan : -----"<<std::endl;
		std::cout<<plan.toString()<<std::endl;
	}
	//--------- END MINIMUM CODE LIBHATP ---------//
	exit(0);
}
